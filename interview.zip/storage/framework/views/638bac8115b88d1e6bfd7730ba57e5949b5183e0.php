<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.master','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Ermploy List
         <?php $__env->endSlot(); ?>

        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Ermploys</h1>
            <div class="btn-toolbar mb-2 mb-md-0">
                <div class="btn-group me-2">
                    <a href="#">

                        <button type="button" class="btn btn-sm btn-outline-secondary">Export PDF</button>
                    </a>

                    <a href="#">

                        <button type="button" class="btn btn-sm btn-outline-secondary">Export Excel</button>
                    </a>

                </div>

                <a href="<?php echo e(route('ermployes.create')); ?>"> <button type="button" class="btn btn-sm btn-outline-primary">
                        <span data-feather="plus"></span>
                        Add New
                    </button> </a>

            </div>
        </div>

        <?php if(session('message')): ?>
        <p class="text-success">
            <?php echo e(session('message')); ?>

        </p>
        <?php endif; ?>




        <table class="table">
            <thead>
                <tr>
                    <th>SL#</th>
                    <th>Name</th>
                    <th>Company Id</th>
                    <th>Company Name </th>
                    <th>Email Address</th>
                    <th>Phone</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>


                <?php $__currentLoopData = $Ermploys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Ermploy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($Ermploy->first_name . $Ermploy->lust_name); ?></td>
                    <td><?php echo e($Ermploy->company_id); ?></td>
                    <td>
                        <?php $__currentLoopData = $AllCom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Allco): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($Ermploy->company_id==$Allco->id): ?>

                        <?php echo e($Allco->name); ?>


                        <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td><?php echo e($Ermploy->email); ?></td>
                    <td><?php echo e($Ermploy->phone); ?></td>
                    <td>
                        <a class="btn btn-sm btn-outline-info" href="<?php echo e(route('ermployes.show', $Ermploy->id)); ?>">Show</a>

                        <a class="btn btn-sm btn-outline-info" href="<?php echo e(route('ermployes.edit', $Ermploy->id)); ?>">Edit</a>
                        <form action="<?php echo e(route('ermployes.destroy', $Ermploy->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button class="btn btn-sm btn-outline-danger">Delete </button>
                        </form>


                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\Interview\resources\views/ermployes/index.blade.php ENDPATH**/ ?>