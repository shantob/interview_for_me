<header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
    <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3" href="#">Company name</a>
    <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <input class="form-control form-control-dark w-100" type="text" placeholder="Search" aria-label="Search">
    <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3" href="#"><?php echo e(Auth::user()->name); ?></a>
        <div class="nav-item text-nowrap">
        <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                
                <a class="nav-link px-3" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                              this.closest('form').submit();">Log Out </a>
            </form>
        </div>
    </div>
</header><?php /**PATH C:\laragon\www\Interview\resources\views/components/partials/header.blade.php ENDPATH**/ ?>