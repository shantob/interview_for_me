<?php foreach($attributes->onlyProps(['name'=> '', 'checklist', 'checkedItems' => []]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['name'=> '', 'checklist', 'checkedItems' => []]); ?>
<?php foreach (array_filter((['name'=> '', 'checklist', 'checkedItems' => []]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php $__currentLoopData = $checklist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



<div class="mb-3 form-check">

    <input 
        name="<?php echo e($name); ?>[]" 
        type="checkbox" 
        id="<?php echo e($key); ?>Input" 
       
        <?php echo e($attributes->merge(['class' => 'form-check-input'])); ?>

        <?php if(in_array($key, $checkedItems)): ?> checked <?php endif; ?>
    >

    <label class="form-check-label" for="<?php echo e($key); ?>Input"><?php echo e($value); ?></label>

</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\laragon\www\class_wark_2\resources\views/components/forms/checkboxcc.blade.php ENDPATH**/ ?>