<?php if(session('message')): ?>
<p class="text-success">
    <?php echo e(session('message')); ?>

</p>
<?php endif; ?><?php /**PATH C:\laragon\www\class_wark_2\resources\views/components/forms/message.blade.php ENDPATH**/ ?>