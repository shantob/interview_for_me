<?php if(session('message')): ?>
<p class="text-success">
    <?php echo e(session('message')); ?>

</p>
<?php endif; ?><?php /**PATH C:\laragon\www\Interview\resources\views/components/forms/message.blade.php ENDPATH**/ ?>