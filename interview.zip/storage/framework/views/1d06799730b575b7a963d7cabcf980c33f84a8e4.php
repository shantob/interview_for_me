<table border="2">
    <thead>
        <tr>
            <th>SL#</th>
            <th>Title</th>
            <th>Category Id</th>
            <th>Category Name </th>
            <th>Product Price</th>
            <th>Active Status</th>
            <th>Description</th>


        </tr>
    </thead>
    <tbody>


        <?php $__currentLoopData = $Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($Product->title); ?></td>
            <td><?php echo e($Product->category_id); ?></td>
            <td>
                <?php $__currentLoopData = $Allcates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Allca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($Product->category_id==$Allca->id): ?>

                <?php echo e($Allca->title); ?>


                <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            <td><?php echo e($Product->price); ?></td>
            <td><?php echo e($Product->is_active? 'Yes' : 'No'); ?>


            </td>
            <td><?php echo e($Product->description); ?></td>



        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\laragon\www\class_wark_2\resources\views/Products/pdf.blade.php ENDPATH**/ ?>