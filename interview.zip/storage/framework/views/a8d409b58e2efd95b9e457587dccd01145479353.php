<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.master','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Course List
         <?php $__env->endSlot(); ?>

        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Courses</h1>
            <div class="btn-toolbar mb-2 mb-md-0">
                <div class="btn-group me-2">
                    <a href="<?php echo e(route('Courses.pdf')); ?>">
                    <button type="button" class="btn btn-sm btn-outline-secondary">Export PDF</button>
                    </a>
                    <a href="<?php echo e(route('Courses.export')); ?>">
                    <button type="button" class="btn btn-sm btn-outline-secondary">Export Excel</button>
                    </a>
                    
                    <a href="<?php echo e(route('Courses.trash')); ?>">
                        <button type="button" class="btn btn-sm btn-outline-danger">Trash</button>

                    </a>
                </div>


                <a href="<?php echo e(route('Courses.create')); ?>"> <button type="button" class="btn btn-sm btn-outline-primary">
                        <span data-feather="plus"></span>
                        Add New
                    </button> </a>

            </div>
        </div>


        <table class="table">
            <thead>
                <tr>
                    <th>SL#</th>
                    <th>Title</th>
                    <th>Category</th>
                    <th>Type</th>
                    <th>Technology </th>
                    <th>Duration</th>
                    <th>Start Date</th>
                    <th>Image</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $Courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($Course->title); ?></td>
                    <td><?php echo e($Course->category); ?></td>
                    <td><?php echo e($Course->type); ?></td>
                    <td> <?php $techs =json_decode($Course->technology)

                        ?>
                        <?php $__currentLoopData = $techs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($tech); ?>,

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </td>
                    <td><?php echo e($Course->duration); ?></td>
                    <td><?php echo e($Course->startdate); ?></td>
                    <td><img src="<?php echo e(asset('storage/courses/'
        .$Course->image)); ?>" height="50" alt="no image"></td>
                    <td>
                        <a class="btn btn-sm btn-outline-info" href="<?php echo e(route('Courses.show', $Course->id)); ?>">Show</a>

                        <a class="btn btn-sm btn-outline-info" href="<?php echo e(route('Courses.edit', $Course->id)); ?>">| Edit |</a>
                        <form action="<?php echo e(route('Courses.destroy', $Course->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button class="btn btn-sm btn-outline-danger" 
                            onclick="return confirm('Are you sure want to delete')"
                            >Delete </button>
                        </form>


                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\class_wark_2\resources\views/Courses/index.blade.php ENDPATH**/ ?>