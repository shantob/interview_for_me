## How to install

- `git clone url`
- `cp .env.example .env`
- `php artisan key:generate`
- `composer update`
- `php artisan serve`